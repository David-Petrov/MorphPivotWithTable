<?php

namespace Database\Factories;

use App\Models\Transfer;
use App\Models\Warehouse;
use Illuminate\Database\Eloquent\Factories\Factory;

class TransferFactory extends Factory
{

    protected $model = Transfer::class;

    public function definition()
    {
        return [
            //
        ];
    }
}
